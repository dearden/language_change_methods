# language_change_methods

A repository of methods for plotting/analysing language change.